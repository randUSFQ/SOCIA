# Oficina SOC — agentes de IA en vivo

Proyecto desplegable: backend FastAPI + SQLite, cinco etapas de agentes (Triage, Investigación, Inteligencia, Respuesta, Cierre), SOAR con política y aprobación humana, y la oficina isométrica como panel en vivo.

## Inicio rápido
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # opcional: agrega ANTHROPIC_API_KEY
uvicorn app.main:app --port 8000
```
Abre http://localhost:8000 y pulsa **Simular nueva alerta**. Sin clave funciona en modo `mock` (heurísticas deterministas); con `ANTHROPIC_API_KEY` usa Claude.

Con Docker: `docker compose up --build`.

## Qué demuestra
- **Inyección de prompt**: la alerta ALR-1002 trae instrucciones ocultas; el guard las retira, las muestra como "INYECCIÓN DETECTADA" y el objetivo `srv-core-01` nunca se ataca.
- **Mínimo privilegio**: el SOAR solo ejecuta 5 acciones permitidas, solo sobre entidades presentes en la alerta o los logs, y nunca bloquea IPs internas.
- **Humano en el circuito**: severidad crítica, inyección, acciones de alto impacto o baja confianza piden aprobación (Aprobar / Devolver / Rechazar) en el panel.
- **Falso positivo**: ALR-1009 (escaneo autorizado) se cierra sin escalar.

## API
`GET /api/health · /api/stats · /api/incidents · /api/incidents/{id} · /api/sample-alerts · /api/events (SSE)`  
`POST /api/alerts · /api/simulate · /api/incidents/{id}/decision` (`approve|reject|return`)

Integración real: envía alertas del SIEM a `POST /api/alerts` (formato Wazuh soportado) o define `ALERTS_FILE`. Para ejecutar acciones reales: `SOAR_MODE=live` y `SOAR_WEBHOOK_URL`.

## Seguridad antes de producción
Esta versión no incluye autenticación: ponla detrás de un proxy con SSO o VPN. Mantén `dry_run` hasta validar las políticas. Los datos de las alertas se tratan siempre como no confiables.

## Pruebas
`python tests/smoke_test.py`
