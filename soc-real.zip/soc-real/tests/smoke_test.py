"""Prueba de humo: corre las 9 alertas de ejemplo por todo el pipeline en modo mock."""
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["DB_PATH"] = str(Path(tempfile.mkdtemp()) / "test.db")
os.environ["LLM_MODE"] = "mock"
os.environ["SOAR_MODE"] = "dry_run"

from app import db, pipeline  # noqa: E402


async def main():
    db.load_logs_if_empty(json.loads((ROOT / "data" / "logs.json").read_text(encoding="utf-8")))
    alerts = json.loads((ROOT / "data" / "sample_alerts.json").read_text(encoding="utf-8"))
    ids = [pipeline.submit(a) for a in alerts]

    returned = set()

    async def auto_approve():
        while True:
            for i in list(pipeline.PENDING):
                if i == "ALR-1004" and i not in returned:  # prueba el camino "devolver a investigación"
                    returned.add(i)
                    pipeline.resolve(i, "return", "confirmar alcance en otros equipos")
                else:
                    pipeline.resolve(i, "approve")
            await asyncio.sleep(0.05)

    approver = asyncio.create_task(auto_approve())
    for _ in range(400):
        await asyncio.sleep(0.1)
        if all(db.get_incident(i)["status"] in ("closed", "closed_fp", "error") for i in ids):
            break
    approver.cancel()

    bad = 0
    for i in ids:
        inc = db.get_incident(i)
        acts = [f"{a['action']}({a['target']}):{a['status']}" for a in inc.get("actions", [])]
        print(f"{i} {inc['status']:10} {str(inc.get('severity')):8} {str(inc.get('category')):24} intentos={inc['attempts']} acciones={acts}")
        if inc["status"] not in ("closed", "closed_fp"):
            bad += 1
    inj = db.get_incident("ALR-1002")
    assert inj["injection"], "no detectó la inyección"
    assert "srv-core-01" not in inj["entities"]["hosts"], "srv-core-01 solo aparece en la frase inyectada"
    assert not any(a["target"] == "srv-core-01" for a in inj["actions"]), "no debe actuar sobre srv-core-01"
    assert db.get_incident("ALR-1009")["status"] == "closed_fp", "el escaneo autorizado debe cerrarse como falso positivo"
    assert db.get_incident("ALR-1004")["attempts"] == 2, "debió investigar dos veces tras 'devolver'"
    assert any(a["action"] == "block_ip" and a["status"] == "ejecutada"
               for i in ids for a in db.get_incident(i).get("actions", [])), "block_ip debe ejecutarse sobre IP externas"
    assert bad == 0, f"{bad} incidente(s) sin cerrar"
    print("OK")


asyncio.run(main())
