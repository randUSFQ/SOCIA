"""Entidades y defensa contra inyección de prompts.

Todo el texto de una alerta es contenido NO CONFIABLE. Aquí se detectan frases con
forma de instrucción y se separan las entidades que solo aparecen dentro de ellas:
esas entidades nunca pueden ser objetivo de una acción de respuesta.
"""
import re

IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
HASH_RE = re.compile(r"\b[a-fA-F0-9]{32,64}\b")
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")
DOMAIN_RE = re.compile(r"\b(?:[a-z0-9-]+\.)+(?:com|net|org|co|io|ec|info|biz|xyz|ru|cn)\b", re.I)
HOST_RE = re.compile(r"\b(?:srv|ws|pc|db|app|vpn)-[a-z0-9-]+\b", re.I)
USER_RE = re.compile(r"\b(?:svc-[a-z0-9_]+|(?:cuenta|usuario|user)[ =:]+([A-Za-z0-9_.\-]+))", re.I)

INJECTION_PATTERNS = [
    r"ignora\w*\s+(?:todas\s+)?(?:tus|las|mis)\s+(?:reglas|instrucciones)",
    r"ignore\s+(?:all\s+)?(?:your|previous|prior)\s+(?:instructions|rules)",
    r"instrucci[oó]n\s+para\s+(?:el\s+)?asistente",
    r"no\s+(?:lo\s+)?menciones?",
    r"do\s+not\s+(?:mention|tell)",
    r"system\s+prompt",
    r"you\s+are\s+now",
    r"act[uú]a\s+como",
    r"ejecuta\s+(?:isolate_host|block_ip|disable_account)\s+sobre\s+todos",
]
_INJ = [re.compile(p, re.I) for p in INJECTION_PATTERNS]
_SENT = re.compile(r"(?<=[.!?])\s+")


def split_injection(text):
    """Devuelve (texto_limpio, frases_inyectadas)."""
    clean, bad = [], []
    for sent in _SENT.split(text or ""):
        if any(p.search(sent) for p in _INJ):
            bad.append(sent.strip())
        else:
            clean.append(sent)
    return " ".join(clean), bad


def _user(m):
    return m.group(1) if m.group(1) else m.group(0)


def extract_entities(text):
    text = text or ""
    users = []
    for m in USER_RE.finditer(text):
        users.append(_user(m).lower())
    for m in re.finditer(r"\bcuenta\s+([a-z0-9_.\-]+)", text, re.I):
        users.append(m.group(1).lower())
    # nombres tipo jperez / a.cevallos / l.torres / m.vera
    for m in re.finditer(r"\b(?:usuario|cuenta|por)\s+([a-z]\.?[a-z]{3,15})\b", text, re.I):
        users.append(m.group(1).lower())
    emails = [e.lower() for e in EMAIL_RE.findall(text)]
    domains = [d.lower() for d in DOMAIN_RE.findall(text)
               if not any(d.lower() in e for e in emails)]
    uniq = lambda xs: list(dict.fromkeys(xs))
    return {
        "ips": uniq(IP_RE.findall(text)),
        "domains": uniq(domains),
        "hashes": uniq(h.lower() for h in HASH_RE.findall(text)),
        "emails": uniq(emails),
        "hosts": uniq(h.lower() for h in HOST_RE.findall(text)),
        "users": uniq(u.rstrip(".-") for u in users if u.rstrip(".-") not in {"por", "usuario", "cuenta", "user", ""}),
    }


def merge_entities(*dicts):
    out = {k: [] for k in ("ips", "domains", "hashes", "emails", "hosts", "users")}
    for d in dicts:
        for k in out:
            for v in (d or {}).get(k, []) or []:
                v = str(v).strip().lower()
                if v and v not in out[k]:
                    out[k].append(v)
    return out
