"""Ejecución de acciones de respuesta (SOAR).

dry_run (por defecto): registra la acción sin tocar ningún sistema.
live: envía cada acción por POST a SOAR_WEBHOOK_URL (tu firewall, EDR o Shuffle/n8n).
"""
import asyncio
import ipaddress
import json
import urllib.request

from . import config, db

ALLOWED = {
    "block_ip": "ips",
    "isolate_host": "hosts",
    "disable_account": "users",
    "reset_credentials": "users",
    "quarantine_email": "emails",
}
HIGH_IMPACT = {"isolate_host", "disable_account"}
INTERNAL_NETS = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")]


def _safe_target(action, target):
    if action == "block_ip":
        try:
            ip = ipaddress.ip_address(target)
        except ValueError:
            return False, "IP inválida"
        if ip.is_loopback or ip.is_link_local or any(ip in n for n in INTERNAL_NETS):
            return False, "no se bloquean IP internas"
    return True, ""


def _post(url, payload):
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=10) as r:  # noqa: S310
        return f"HTTP {r.status}"


async def execute(incident_id, action, target):
    ok, why = _safe_target(action, target)
    if not ok:
        db.add_action(incident_id, action, target, config.SOAR_MODE, "descartada", why)
        return {"action": action, "target": target, "status": "descartada", "result": why}
    if config.SOAR_MODE == "live" and config.SOAR_WEBHOOK_URL:
        try:
            result = await asyncio.get_running_loop().run_in_executor(
                None, _post, config.SOAR_WEBHOOK_URL,
                {"incident": incident_id, "action": action, "target": target})
            status = "ejecutada"
        except Exception as exc:  # noqa: BLE001
            result, status = str(exc), "error"
    else:
        result, status = "simulada (dry_run)", "ejecutada"
    db.add_action(incident_id, action, target, config.SOAR_MODE, status, result)
    return {"action": action, "target": target, "status": status, "result": result}
