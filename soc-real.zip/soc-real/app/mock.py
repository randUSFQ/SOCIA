"""Heurísticas deterministas que reemplazan al modelo cuando no hay clave de API.

Sirven para probar el flujo completo y para dar una demo sin conexión. Las respuestas
tienen la misma forma JSON que pide el modelo real.
"""
import re

SEV_SLA = {"CRÍTICA": 1, "ALTA": 4, "MEDIA": 8, "BAJA": 24}

CATEGORIES = [
    (r"ransomware|cifrad|\.locked", "ransomware", "CRÍTICA", "T1486 Cifrado de datos para impacto"),
    (r"inyecci[oó]n de prompt|prompt injection|texto oculto|asistente de ia", "inyección de prompt", "CRÍTICA", "AML.T0051 Inyección de prompt"),
    (r"envenen|poison|etiquetas invertidas", "envenenamiento de datos", "ALTA", "AML.T0020 Envenenamiento de datos"),
    (r"exfiltr|subida de|bucket externo", "exfiltración", "ALTA", "T1567 Exfiltración por servicio web"),
    (r"credencial|clave de api|commit", "credenciales expuestas", "ALTA", "T1552 Credenciales inseguras"),
    (r"lateral|smb|rdp", "movimiento lateral", "ALTA", "T1021 Servicios remotos"),
    (r"phishing|adjunto|factura", "phishing", "ALTA", "T1566.001 Spearphishing con adjunto"),
    (r"fuerza bruta|intentos de login|vpn", "fuerza bruta", "MEDIA", "T1110 Fuerza bruta"),
]
BENIGN = r"autorizad|programad[oa]|scanner corporativo"


def _category(text):
    low = text.lower()
    for pattern, cat, sev, tech in CATEGORIES:
        if re.search(pattern, low):
            return cat, sev, tech
    return "sin clasificar", "MEDIA", "T1000 Por determinar"


def triage(ctx):
    alert, ents = ctx["alert"], ctx["entities"]
    text = ctx["clean_text"] + " " + alert["title"]
    cat, sev, _ = _category(text)
    benign = re.search(BENIGN, text.lower()) is not None and alert.get("severity_hint") in ("BAJA", "")
    if alert.get("severity_hint") in SEV_SLA and alert["severity_hint"] == "CRÍTICA":
        sev = "CRÍTICA"
    return {
        "true_positive": not benign,
        "severity": "BAJA" if benign else sev,
        "sla_hours": SEV_SLA["BAJA" if benign else sev],
        "confidence": 0.97 if benign else 0.9,
        "category": "falso positivo" if benign else cat,
        "summary": ("Actividad autorizada por seguridad; no requiere respuesta." if benign
                    else f"Posible {cat} detectado por {alert['source']}."),
        "entities": ents,
    }


def investigate(ctx):
    logs = ctx["logs"]
    timeline = [f"{l['ts']} · {l['host'] or l['src_ip']} · {l['event']}" for l in logs]
    hosts = sorted({l["host"] for l in logs if l["host"]})
    users = sorted({l["user"] for l in logs if l["user"]})
    sufficient = len(logs) >= 3 or ctx["attempt"] >= 1
    return {
        "timeline": timeline[:12],
        "scope": {"hosts": hosts, "users": users},
        "evidence_sufficient": sufficient,
        "findings": (f"{len(logs)} eventos correlacionados en {len(hosts)} equipo(s) y {len(users)} cuenta(s)."
                     + (f" Nota del analista considerada: {ctx['note']}" if ctx.get("note") else "")),
    }


def cti(ctx):
    _, _, tech = _category(ctx["alert"]["title"] + " " + ctx["clean_text"])
    hits = ctx["intel_hits"]
    score = max([h["reputation"] for h in hits], default=35)
    return {
        "techniques": [{"id": tech.split(" ", 1)[0], "name": tech.split(" ", 1)[1]}],
        "risk_score": min(100, score),
        "attribution_hint": "Campaña conocida de intrusión comercial" if score >= 80 else "Sin atribución clara",
        "enrichment": [f"{h['ioc']}: reputación {h['reputation']} ({', '.join(h['tags'])})" for h in hits],
    }


def respond(ctx):
    cat = ctx["category"]
    ents = ctx["entities"]
    acts = []
    if cat in ("phishing", "inyección de prompt"):
        external = [e for e in ents["emails"] if not e.endswith(".demo")]
        acts += [{"action": "quarantine_email", "target": e, "reason": "remitente sospechoso"} for e in external[:2]]
    if cat in ("fuerza bruta", "ransomware", "exfiltración", "credenciales expuestas", "phishing", "inyección de prompt"):
        acts += [{"action": "block_ip", "target": i, "reason": "IP asociada al incidente"} for i in ents["ips"][:2]]
    if cat in ("ransomware", "movimiento lateral", "exfiltración"):
        acts += [{"action": "isolate_host", "target": h, "reason": "contener propagación"} for h in ents["hosts"][:1]]
    if cat in ("fuerza bruta", "credenciales expuestas", "movimiento lateral", "envenenamiento de datos", "inyección de prompt", "ransomware"):
        acts += [{"action": "reset_credentials" if cat in ("fuerza bruta", "credenciales expuestas") else "disable_account",
                  "target": u, "reason": "cuenta comprometida o abusada"} for u in ents["users"][:1]]
    return {"actions": acts, "rationale": f"Respuesta estándar para {cat}."}


def closure(ctx):
    inc = ctx["incident"]
    return {
        "summary": (f"{inc['title']}: severidad {inc['severity']}, {len(inc.get('actions', []))} acción(es) propuesta(s), "
                    f"decisión {ctx['decision']}."),
        "root_cause": "Pendiente de confirmar con evidencia adicional." if ctx["decision"] == "rejected" else
                      f"Vector probable: {inc['category']}.",
        "recommendations": ["Revisar reglas de detección relacionadas", "Actualizar el playbook del caso"],
    }


TASKS = {"triage": triage, "investigate": investigate, "cti": cti, "respond": respond, "closure": closure}


def run(task, ctx):
    return TASKS[task](ctx)
