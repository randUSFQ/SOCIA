"""Acceso al modelo. Anthropic en producción; modo mock determinista para demos sin clave."""
import json
import os

from . import config, mock


def extract_json(text):
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("la respuesta no contiene JSON")
    return json.loads(text[start:end + 1])


class MockLLM:
    name = "mock (sin clave)"

    async def json(self, task, system, user, ctx):
        return mock.run(task, ctx)


class AnthropicLLM:
    def __init__(self):
        import anthropic  # import perezoso: el modo mock no lo necesita

        self.client = anthropic.AsyncAnthropic()
        self.name = f"anthropic · {config.MODEL}"

    async def json(self, task, system, user, ctx):
        prompt = user
        last = None
        for _ in range(2):
            resp = await self.client.messages.create(
                model=config.MODEL,
                max_tokens=1800,
                system=system,
                messages=[{"role": "user", "content": prompt}],
            )
            text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
            try:
                return extract_json(text)
            except Exception as exc:  # noqa: BLE001
                last = exc
                prompt = user + "\n\nResponde únicamente con un objeto JSON válido, sin texto adicional."
        raise ValueError(f"JSON inválido del modelo: {last}")


_llm = None


def get_llm():
    global _llm
    if _llm is not None:
        return _llm
    mode = config.LLM_MODE
    has_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    if mode == "mock" or (mode == "auto" and not has_key):
        _llm = MockLLM()
    else:
        if not has_key:
            raise RuntimeError("LLM_MODE=anthropic requiere ANTHROPIC_API_KEY")
        _llm = AnthropicLLM()
    return _llm
