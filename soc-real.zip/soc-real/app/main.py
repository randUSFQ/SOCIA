"""API del SOC: ingesta de alertas, eventos en vivo (SSE), aprobaciones humanas y panel web."""
import asyncio
import json
from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import config, db, pipeline
from .llm import get_llm

_sim_index = 0


def _load_json(name, default):
    path = config.DATA_DIR / name
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


async def _tail_file(path):
    """Vigila un archivo JSONL (por ejemplo alerts.json de Wazuh) y envía cada línea nueva al SOC."""
    pos = None
    while True:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                fh.seek(0, 2) if pos is None else fh.seek(pos)
                for line in fh:
                    line = line.strip()
                    if line:
                        try:
                            pipeline.submit(json.loads(line))
                        except json.JSONDecodeError:
                            pipeline.submit({"title": line[:80], "source": "archivo", "raw": line})
                pos = fh.tell()
        except FileNotFoundError:
            pass
        await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(app):
    db.load_logs_if_empty(_load_json("logs.json", []))
    tail = asyncio.create_task(_tail_file(config.ALERTS_FILE)) if config.ALERTS_FILE else None
    yield
    if tail:
        tail.cancel()


app = FastAPI(title="Oficina SOC", lifespan=lifespan)


class Decision(BaseModel):
    decision: str
    note: str = ""


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/stats")
def stats():
    incs = db.list_incidents(500)
    return {
        "alerts": len(incs),
        "triaged": sum(1 for i in incs if i.get("severity") and i["status"] != "closed_fp"),
        "investigated": sum(1 for i in incs if i.get("timeline") is not None),
        "intel": sum(1 for i in incs if i.get("techniques") is not None),
        "contained": sum(1 for i in incs if any(a["status"] == "ejecutada" for a in i.get("actions", []))),
        "closed": sum(1 for i in incs if i["status"] in ("closed", "closed_fp")),
        "active": sum(1 for i in incs if i["status"] not in ("closed", "closed_fp", "error")),
        "llm": get_llm().name,
        "soar": config.SOAR_MODE,
    }


@app.get("/api/incidents")
def incidents():
    return [pipeline.summary(i) for i in db.list_incidents(60)]


@app.get("/api/incidents/{inc_id}")
def incident(inc_id: str):
    inc = db.get_incident(inc_id)
    if not inc:
        raise HTTPException(404, "incidente no encontrado")
    inc = {k: v for k, v in inc.items() if k not in ("clean_text",)}
    inc["soar_log"] = db.list_actions(inc_id)
    return inc


@app.post("/api/alerts")
async def ingest(payload: dict = Body(...)):
    return {"id": pipeline.submit(payload)}


@app.get("/api/sample-alerts")
def samples():
    return _load_json("sample_alerts.json", [])


@app.post("/api/simulate")
async def simulate():
    global _sim_index
    alerts = _load_json("sample_alerts.json", [])
    if not alerts:
        raise HTTPException(404, "no hay alertas de ejemplo")
    alert = dict(alerts[_sim_index % len(alerts)])
    _sim_index += 1
    return {"id": pipeline.submit(alert)}


@app.post("/api/incidents/{inc_id}/decision")
async def decide(inc_id: str, body: Decision):
    if body.decision not in ("approve", "reject", "return"):
        raise HTTPException(400, "decision debe ser approve, reject o return")
    if not pipeline.resolve(inc_id, body.decision, body.note):
        raise HTTPException(409, "el incidente no espera una decisión")
    return {"ok": True}


@app.get("/api/events")
async def events():
    q = pipeline.bus.subscribe()
    history = db.recent_events(60)

    async def stream():
        try:
            for ev in history:
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
            while True:
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            pipeline.bus.unsubscribe(q)

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


app.mount("/", StaticFiles(directory=str(config.STATIC_DIR), html=True), name="static")
