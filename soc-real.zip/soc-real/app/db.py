"""Persistencia en SQLite: incidentes, eventos, acciones SOAR y logs de contexto."""
import json
import sqlite3
import threading
import time

from . import config

_lock = threading.Lock()
_conn = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(
  id TEXT PRIMARY KEY, created REAL, status TEXT, stage TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, incident TEXT, type TEXT, payload TEXT);
CREATE TABLE IF NOT EXISTS actions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, incident TEXT, action TEXT,
  target TEXT, mode TEXT, status TEXT, result TEXT);
CREATE TABLE IF NOT EXISTS logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, host TEXT, user TEXT,
  src_ip TEXT, dst TEXT, event TEXT);
"""


def conn():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.executescript(SCHEMA)
        _conn.commit()
    return _conn


def reset_connection():
    """Solo para pruebas: cierra la conexión actual."""
    global _conn
    if _conn is not None:
        _conn.close()
    _conn = None


def _run(sql, args=(), write=False):
    with _lock:
        cur = conn().execute(sql, args)
        rows = cur.fetchall()
        last = cur.lastrowid
        if write:
            conn().commit()
    return rows, last


# ---- incidentes ----
def save_incident(inc):
    _run(
        "INSERT INTO incidents(id,created,status,stage,data) VALUES(?,?,?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET status=excluded.status, stage=excluded.stage, data=excluded.data",
        (inc["id"], inc["created"], inc["status"], inc.get("stage", "grants"),
         json.dumps(inc, ensure_ascii=False)),
        write=True,
    )


def get_incident(inc_id):
    rows, _ = _run("SELECT data FROM incidents WHERE id=?", (inc_id,))
    return json.loads(rows[0]["data"]) if rows else None


def list_incidents(limit=60):
    rows, _ = _run("SELECT data FROM incidents ORDER BY created DESC LIMIT ?", (limit,))
    return [json.loads(r["data"]) for r in reversed(rows)]


# ---- eventos ----
def add_event(ev):
    _run(
        "INSERT INTO events(ts,incident,type,payload) VALUES(?,?,?,?)",
        (ev["ts"], ev.get("incident"), ev["type"], json.dumps(ev, ensure_ascii=False)),
        write=True,
    )


def recent_events(limit=60):
    rows, _ = _run("SELECT payload FROM events ORDER BY id DESC LIMIT ?", (limit,))
    return [json.loads(r["payload"]) for r in reversed(rows)]


# ---- acciones SOAR ----
def add_action(incident, action, target, mode, status, result):
    _, last = _run(
        "INSERT INTO actions(ts,incident,action,target,mode,status,result) VALUES(?,?,?,?,?,?,?)",
        (time.time(), incident, action, target, mode, status, result),
        write=True,
    )
    return last


def list_actions(incident):
    rows, _ = _run("SELECT * FROM actions WHERE incident=? ORDER BY id", (incident,))
    return [dict(r) for r in rows]


# ---- logs de contexto ----
def load_logs_if_empty(rows):
    count, _ = _run("SELECT COUNT(*) AS n FROM logs")
    if count[0]["n"]:
        return
    with _lock:
        conn().executemany(
            "INSERT INTO logs(ts,host,user,src_ip,dst,event) VALUES(?,?,?,?,?,?)",
            [(r.get("ts", ""), r.get("host", ""), r.get("user", ""), r.get("src_ip", ""),
              r.get("dst", ""), r.get("event", "")) for r in rows],
        )
        conn().commit()


def query_logs(values, limit=40):
    """Busca eventos que mencionen cualquiera de los valores (host, usuario, IP, dominio, hash)."""
    values = [v for v in dict.fromkeys(values) if v]
    if not values:
        return []
    clauses, args = [], []
    for v in values:
        clauses.append("(host=? OR user=? OR src_ip=? OR dst=? OR event LIKE ?)")
        args += [v, v, v, v, f"%{v}%"]
    rows, _ = _run(
        f"SELECT ts,host,user,src_ip,dst,event FROM logs WHERE {' OR '.join(clauses)} ORDER BY ts LIMIT ?",
        (*args, limit),
    )
    return [dict(r) for r in rows]
