"""Convierte alertas de distintos orígenes (Wazuh, JSON genérico, texto) a un formato único."""
import json
import uuid

LEVEL_TO_SEV = [(12, "CRÍTICA"), (9, "ALTA"), (5, "MEDIA"), (0, "BAJA")]


def _level_to_sev(level):
    try:
        level = int(level)
    except (TypeError, ValueError):
        return ""
    for minimum, sev in LEVEL_TO_SEV:
        if level >= minimum:
            return sev
    return "BAJA"


def normalize(payload):
    p = payload if isinstance(payload, dict) else {"raw": str(payload)}
    rule = p.get("rule") if isinstance(p.get("rule"), dict) else {}
    title = p.get("title") or rule.get("description") or p.get("name") or "Alerta sin título"
    source = p.get("source") or ("Wazuh" if rule else "manual")
    raw = p.get("raw") or p.get("full_log")
    if not raw:
        raw = json.dumps(p, ensure_ascii=False)
    if not isinstance(raw, str):
        raw = json.dumps(raw, ensure_ascii=False)
    title = str(title).strip()
    short = p.get("short") or (title if len(title) <= 26 else title[:25] + "…")
    return {
        "id": str(p.get("id") or "INC-" + uuid.uuid4().hex[:6].upper()),
        "title": title[:140],
        "short": short,
        "source": str(source)[:60],
        "severity_hint": str(p.get("severity") or _level_to_sev(rule.get("level")) or "").upper(),
        "raw": raw[:6000],
    }
