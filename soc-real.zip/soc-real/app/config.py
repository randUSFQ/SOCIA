"""Configuración del SOC. Lee variables de entorno y un archivo .env opcional."""
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


def _load_dotenv():
    path = BASE / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv()


def env(key, default=""):
    return os.environ.get(key, default)


# auto = Anthropic si hay ANTHROPIC_API_KEY, si no mock | anthropic | mock
LLM_MODE = env("LLM_MODE", "auto").lower()
MODEL = env("ANTHROPIC_MODEL", "claude-sonnet-5-5")
DB_PATH = env("DB_PATH", str(BASE / "soc.db"))
WORKERS = int(env("WORKERS", "2"))

# dry_run: registra las acciones sin ejecutarlas. live: envía cada acción a SOAR_WEBHOOK_URL.
SOAR_MODE = env("SOAR_MODE", "dry_run").lower()
SOAR_WEBHOOK_URL = env("SOAR_WEBHOOK_URL", "")

# Archivo JSONL a vigilar (por ejemplo /var/ossec/logs/alerts/alerts.json de Wazuh)
ALERTS_FILE = env("ALERTS_FILE", "")

DATA_DIR = BASE / "data"
STATIC_DIR = BASE / "static"
