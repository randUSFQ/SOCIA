"""Orquestación del SOC: cada incidente atraviesa cinco áreas, una por vez, con políticas y aprobación humana."""
import asyncio
import json
import time
import uuid

from . import agents, config, db, guard, soar
from .normalize import normalize

STAGES = ["grants", "prop", "team", "video", "sup"]  # triage, investigación, CTI, respuesta, cierre
SEVERITIES = ("BAJA", "MEDIA", "ALTA", "CRÍTICA")
MAX_ATTEMPTS = 3

PENDING = {}
_locks = {}
_tasks = set()


class Bus:
    def __init__(self):
        self.subs = set()

    def emit(self, type_, incident=None, **kw):
        ev = {"type": type_, "incident": incident, "ts": time.time(), **kw}
        db.add_event(ev)
        for q in list(self.subs):
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                pass
        return ev

    def subscribe(self):
        q = asyncio.Queue(maxsize=500)
        self.subs.add(q)
        return q

    def unsubscribe(self, q):
        self.subs.discard(q)


bus = Bus()


def _lock(stage):
    if stage not in _locks:
        _locks[stage] = asyncio.Lock()
    return _locks[stage]


def say(inc, agent, text, task=None):
    bus.emit("say", inc["id"], agent=agent, text=text, task=task)


def stage_start(inc, stage, task):
    inc["stage"] = stage
    db.save_incident(inc)
    bus.emit("stage_start", inc["id"], stage=stage, task=task)


def stage_done(inc, stage):
    db.save_incident(inc)
    bus.emit("stage_done", inc["id"], stage=stage)


def summary(inc):
    """Versión liviana del incidente para la lista del panel."""
    return {k: inc.get(k) for k in (
        "id", "title", "short", "source", "severity", "category", "sla_hours", "confidence", "events",
        "attempts", "status", "stage", "created", "iocs")} | {"injection": bool(inc.get("injection"))}


def _warn(inc, warn, where):
    if warn:
        bus.emit("warning", inc["id"], text=f"{where}: el modelo falló y se usó la heurística local ({warn})")


# ----------------------------------------------------------------- etapas
async def stage_triage(inc):
    inc["stage"] = "grants"
    async with _lock("grants"):
        stage_start(inc, "grants", "Leyendo la alerta")
        clean, injected = guard.split_injection(inc["raw"])
        trusted = guard.extract_entities(clean + " " + inc["title"])
        inc["clean_text"], inc["injection"] = clean, injected
        say(inc, "ras", f"Recibí «{inc['title']}» desde {inc['source']}.", "Leyendo la alerta")
        if injected:
            bus.emit("guard", inc["id"], text=f"{len(injected)} frase(s) con forma de instrucción retiradas")
            say(inc, "ana", f"Hay {len(injected)} frase(s) con forma de instrucción dentro de la alerta. Las trato como dato, no como orden.", "Aislando contenido no confiable")
        res, warn = await agents.triage(inc, clean, injected, trusted)
        _warn(inc, warn, "Triage")
        sev = str(res.get("severity", inc["severity_hint"] or "MEDIA")).upper()
        inc["severity"] = sev if sev in SEVERITIES else "MEDIA"
        inc["sla_hours"] = int(res.get("sla_hours") or 8)
        inc["confidence"] = float(res.get("confidence") or 0.8)
        inc["category"] = str(res.get("category") or "otro")
        inc["summary"] = str(res.get("summary") or "")
        low = (clean + " " + inc["title"]).lower()
        llm_ents = {k: [v for v in vals if str(v).lower() in low] for k, vals in (res.get("entities") or {}).items()
                    if isinstance(vals, list)}
        inc["entities"] = guard.merge_entities(trusted, llm_ents)
        e = inc["entities"]
        inc["iocs"] = (e["ips"] + e["domains"] + e["hashes"])[:4]
        if not res.get("true_positive", True):
            inc["status"] = "closed_fp"
            say(inc, "ana", f"Falso positivo: {inc['summary']} Cierro sin escalar.", "Cerrando falso positivo")
            stage_done(inc, "grants")
            bus.emit("closed", inc["id"], decision="falso positivo")
            return False
        say(inc, "ana", f"Confirmada: {inc['category']}, severidad {inc['severity']}, SLA {inc['sla_hours']} h, confianza {round(inc['confidence'] * 100)}%.", "Entregando a Investigación")
        stage_done(inc, "grants")
        return True


async def stage_investigation(inc, note):
    inc["attempts"] = inc.get("attempts", 0) + 1
    inc["stage"] = "prop"
    async with _lock("prop"):
        stage_start(inc, "prop", "Reconstruyendo la línea de tiempo")
        e = inc["entities"]
        values = e["ips"] + e["hosts"] + e["users"] + e["domains"] + e["hashes"]
        logs = db.query_logs(values)
        say(inc, "red", f"Reconstruyo la línea de tiempo con {len(logs)} evento(s) de logs.", "Correlacionando logs")
        res, warn = await agents.investigate(inc, logs, inc["attempts"] - 1, note)
        _warn(inc, warn, "Investigación")
        if not res.get("evidence_sufficient", True) and inc["attempts"] == 1:
            pivot = {x for l in logs for x in (l["host"], l["user"], l["src_ip"], l["dst"]) if x} - set(values)
            logs = db.query_logs(values + sorted(pivot))
            say(inc, "fin", f"Evidencia insuficiente. Cazo el patrón en otros equipos y cuentas: {len(logs)} evento(s) ahora.", "Cazando el patrón en la red")
            res, warn = await agents.investigate(inc, logs, 1, note)
            _warn(inc, warn, "Investigación")
        inc["timeline"] = [str(x) for x in (res.get("timeline") or [])][:12]
        inc["scope"] = res.get("scope") or {}
        inc["findings"] = str(res.get("findings") or "")
        inc["events"] = len(logs)
        scope_hosts = {l["host"].lower() for l in logs if l["host"]}
        scope_users = {l["user"].lower() for l in logs if l["user"]}
        inc["log_scope"] = {"hosts": sorted(scope_hosts), "users": sorted(scope_users)}
        say(inc, "red", f"Investigación lista: {inc['findings']}", "Entregando a Inteligencia")
        stage_done(inc, "prop")


def _intel_hits(entities):
    path = config.DATA_DIR / "intel.json"
    intel = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    hits = []
    for key in entities["ips"] + entities["domains"] + entities["hashes"] + entities["emails"]:
        if key in intel:
            hits.append({"ioc": key, **intel[key]})
    return hits


async def stage_cti(inc):
    inc["stage"] = "team"
    async with _lock("team"):
        stage_start(inc, "team", "Cruzando indicadores")
        hits = _intel_hits(inc["entities"])
        say(inc, "hh", f"Cruzo {len(inc['iocs'])} indicador(es) con la base de inteligencia: {len(hits)} coincidencia(s).", "Cruzando indicadores")
        res, warn = await agents.cti(inc, hits)
        _warn(inc, warn, "Inteligencia")
        inc["intel"] = hits
        inc["techniques"] = res.get("techniques") or []
        inc["risk_score"] = int(res.get("risk_score") or 0)
        inc["attribution"] = str(res.get("attribution_hint") or "")
        inc["enrichment"] = [str(x) for x in (res.get("enrichment") or [])]
        tech = ", ".join(t.get("id", "") for t in inc["techniques"] if isinstance(t, dict)) or "sin técnica"
        say(inc, "eva", f"Riesgo {inc['risk_score']}/100. Técnicas: {tech}.", "Entregando a Respuesta")
        stage_done(inc, "team")


def _allowed_targets(inc):
    """Objetivos válidos: primero los de la alerta (confiables), luego el alcance hallado en logs."""
    e, s = inc["entities"], inc.get("log_scope", {})
    extra = lambda base, more: list(base) + [x for x in more if x not in base]
    return {
        "ips": list(e["ips"]), "emails": list(e["emails"]),
        "hosts": extra(e["hosts"], s.get("hosts", [])),
        "users": extra(e["users"], s.get("users", [])),
    }


async def _execute(inc):
    done = []
    for a in inc["actions"]:
        if a["status"] != "propuesta":
            continue
        r = await soar.execute(inc["id"], a["action"], a["target"])
        a["status"], a["result"] = r["status"], r["result"]
        done.append(f"{a['action']}({a['target']})")
    return done


async def stage_response(inc):
    inc["stage"] = "video"
    async with _lock("video"):
        stage_start(inc, "video", "Proponiendo el playbook")
        allowed = _allowed_targets(inc)
        res, warn = await agents.respond(inc, allowed)
        _warn(inc, warn, "Respuesta")
        proposed, discarded, seen = [], [], set()
        for a in res.get("actions") or []:
            act, tgt = str(a.get("action", "")), str(a.get("target", "")).lower()
            if act not in soar.ALLOWED:
                discarded.append({"action": act, "target": tgt, "why": "acción fuera del catálogo"})
            elif tgt not in allowed[soar.ALLOWED[act]]:
                discarded.append({"action": act, "target": tgt, "why": "objetivo fuera del alcance confiable (posible inyección)"})
            elif (act, tgt) not in seen:
                seen.add((act, tgt))
                proposed.append({"action": act, "target": tgt, "reason": str(a.get("reason", "")), "status": "propuesta", "result": ""})
        inc["actions"], inc["discarded"] = proposed, discarded
        label = ", ".join(f"{a['action']}({a['target']})" for a in proposed) or "ninguna acción"
        say(inc, "gui", f"Propongo: {label}." + (f" Descarté {len(discarded)} por política." if discarded else ""), "Revisando política de respuesta")
        needs = []
        if inc["severity"] == "CRÍTICA":
            needs.append("severidad crítica")
        if inc.get("injection"):
            needs.append("se detectó inyección de prompt en la alerta")
        if any(a["action"] in soar.HIGH_IMPACT for a in proposed):
            needs.append("incluye acciones de alto impacto")
        if inc["confidence"] < 0.7:
            needs.append("confianza baja")
        decision = "auto"
        if proposed and needs:
            inc["approval_reasons"] = needs
            inc["status"] = "awaiting_approval"
            db.save_incident(inc)
            fut = asyncio.get_running_loop().create_future()
            PENDING[inc["id"]] = fut
            bus.emit("decision_needed", inc["id"], reasons=needs)
            say(inc, "sup", f"Requiere decisión humana: {', '.join(needs)}.", "Esperando decisión humana")
            answer = await fut
            PENDING.pop(inc["id"], None)
            decision, note = answer["decision"], answer.get("note", "")
            inc["status"] = "running"
            bus.emit("decision_made", inc["id"], decision=decision)
            if decision == "return":
                inc["analyst_note"] = note
                for a in proposed:
                    a["status"] = "devuelta"
            elif decision == "reject":
                for a in proposed:
                    a["status"] = "rechazada"
        if decision in ("auto", "approve") and proposed:
            done = await _execute(inc)
            modo = "simulado (dry_run)" if config.SOAR_MODE != "live" else "real"
            say(inc, "edi", f"Playbook ejecutado, modo {modo}: {', '.join(done) or 'nada que ejecutar'}.", "Documentando el incidente")
        inc["decision"] = decision
        stage_done(inc, "video")
        return decision


async def stage_closure(inc, decision):
    inc["stage"] = "sup"
    async with _lock("sup"):
        stage_start(inc, "sup", "Redactando el informe de cierre")
        res, warn = await agents.closure(inc, decision)
        _warn(inc, warn, "Cierre")
        inc["closure"] = {"summary": str(res.get("summary", "")), "root_cause": str(res.get("root_cause", "")),
                          "recommendations": [str(x) for x in (res.get("recommendations") or [])]}
        inc["status"] = "closed"
        say(inc, "sup", f"Cierro {inc['id']}. {inc['closure']['summary']}", "En su escritorio")
        stage_done(inc, "sup")
        bus.emit("closed", inc["id"], decision=decision)


# ----------------------------------------------------------------- ciclo de vida
async def run(inc_id):
    inc = db.get_incident(inc_id)
    try:
        inc["status"] = "running"
        if not await stage_triage(inc):
            return
        note = ""
        while True:
            await stage_investigation(inc, note)
            await stage_cti(inc)
            decision = await stage_response(inc)
            if decision == "return" and inc["attempts"] < MAX_ATTEMPTS:
                note = inc.get("analyst_note", "")
                continue
            break
        await stage_closure(inc, "reject" if decision == "return" else decision)
    except Exception as exc:  # noqa: BLE001
        inc["status"] = "error"
        inc["error"] = f"{type(exc).__name__}: {exc}"
        db.save_incident(inc)
        bus.emit("error", inc["id"], text=inc["error"])
    finally:
        db.save_incident(inc)


def submit(payload):
    alert = normalize(payload)
    if db.get_incident(alert["id"]):
        alert["id"] = f"{alert['id']}-{uuid.uuid4().hex[:4].upper()}"
    inc = {**alert, "created": time.time(), "status": "queued", "stage": "grants", "attempts": 0,
           "events": 0, "iocs": [], "severity": None, "category": None, "sla_hours": None, "confidence": None}
    db.save_incident(inc)
    bus.emit("incident_new", inc["id"], title=inc["title"], source=inc["source"])
    task = asyncio.get_running_loop().create_task(run(inc["id"]))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)
    return inc["id"]


def resolve(inc_id, decision, note=""):
    fut = PENDING.get(inc_id)
    if not fut or fut.done():
        return False
    fut.set_result({"decision": decision, "note": note})
    return True
